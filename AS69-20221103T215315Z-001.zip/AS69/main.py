alphabets = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o","p","q","r","s","t","u","v","w","x","y","z"]
Caeser = ["g", "h", "i", "j", "k", "l", "m", "n", "o","p","q","r","s","t","u","v","w","x","y","z", "a", "b", "c", "d", "e", "f"]
length = 0
final = ""
x = 0
with open('text','r') as file:
    data = file.read()
    data = data.lower()
    file.close()

def encode(string):
        length = len(data)
        final = ""
        for i in range(length):
            if data[i] in alphabets:
                x = alphabets.index(data[i])
                final += str(Caeser[x])
                #print(Caeser[x], end="")
            else:
                #print(data[i], end="")
                final += str(data[i])
        print(final)
        with open('text', 'r+') as file:
            file.truncate()
        file.close()

        with open('text', 'a') as file:
            file.write(final)


def decode(string):
    length = len(data)
    final = ""
    for i in range(length):
        if data[i] in Caeser:
            x = Caeser.index(data[i])
            final += str(alphabets[x])
        else:
            final += str(data[i])
    print(final)
    with open('text', 'r+') as file:
        file.truncate()
    file.close()

    with open('text', 'a') as file:
        file.write(final)

choice = int(input("Press 1 for encoding, 2 for decoding"))
if choice == 1:
    encode(data)

if choice == 2:
    decode(data)