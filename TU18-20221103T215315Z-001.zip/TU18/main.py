import time
def read():
    filename = input("what is your file called")
    with open(filename,"r") as whole_file:
       for line in whole_file:
            print(line,end="")
            time.sleep(2)

read()